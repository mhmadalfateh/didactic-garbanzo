(() => {
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const healthEl=document.getElementById('health'),scoreEl=document.getElementById('score');
let W=0,H=0,playing=false,health=100,score=0,shots=[],targets=[],keys={},last=0;
const player={x:0,y:0,angle:0};
function resize(){W=canvas.width=innerWidth*devicePixelRatio;H=canvas.height=innerHeight*devicePixelRatio;canvas.style.width=innerWidth+'px';canvas.style.height=innerHeight+'px';ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);W=innerWidth;H=innerHeight;spawnTargets();}
addEventListener('resize',resize);
function spawnTargets(){targets=[];for(let i=0;i<9;i++)targets.push({x:(Math.random()-.5)*900,y:180+Math.random()*650,r:18+Math.random()*10,alive:true});}
function project(x,y){const scale=520/(y+300);return {x:W/2+x*scale,y:H*.52+(y-player.y)*scale,scale};}
function drawTree(x,y,s){let p=project(x,y);ctx.fillStyle='#493a28';ctx.fillRect(p.x-3*s,p.y,6*s,22*s);ctx.fillStyle='#254d32';ctx.beginPath();ctx.moveTo(p.x,p.y-45*s);ctx.lineTo(p.x-23*s,p.y+3*s);ctx.lineTo(p.x+23*s,p.y+3*s);ctx.closePath();ctx.fill();}
function render(){ctx.clearRect(0,0,W,H);let sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#86b9c3');sky.addColorStop(.55,'#d2d0a0');sky.addColorStop(1,'#4e6840');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
ctx.fillStyle='#647b4b';ctx.beginPath();ctx.moveTo(0,H*.48);ctx.lineTo(W,H*.48);ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.fill();
ctx.fillStyle='#857c59';ctx.beginPath();ctx.moveTo(W*.42,H);ctx.lineTo(W*.48,H*.49);ctx.lineTo(W*.52,H*.49);ctx.lineTo(W*.64,H);ctx.fill();
for(let i=0;i<22;i++){let x=((i*137)%W),y=H*.45+(i%7)*H*.075;drawTree((x-W/2)*1.8,150+(i%6)*100,.55+(i%5)*.13);}
targets.forEach(t=>{if(!t.alive)return;let p=project(t.x,t.y);let s=Math.max(.25,p.scale);ctx.fillStyle='#252b2a';ctx.fillRect(p.x-11*s,p.y-26*s,22*s,35*s);ctx.fillStyle='#c2a77c';ctx.beginPath();ctx.arc(p.x,p.y-32*s,9*s,0,Math.PI*2);ctx.fill();ctx.fillStyle='#b54531';ctx.fillRect(p.x-7*s,p.y-39*s,14*s,4*s);});
ctx.fillStyle='#20262a';ctx.beginPath();ctx.moveTo(W*.43,H);ctx.lineTo(W*.46,H*.77);ctx.lineTo(W*.54,H*.77);ctx.lineTo(W*.59,H);ctx.fill();ctx.fillStyle='#3c4447';ctx.fillRect(W*.48,H*.75,W*.04,H*.25);ctx.fillStyle='#161b1d';ctx.fillRect(W*.495,H*.68,W*.01,H*.12);
shots.forEach(s=>{ctx.strokeStyle='#ffe7a1';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(W/2,H*.78);ctx.lineTo(s.x,s.y);ctx.stroke();});
ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(W/2-9,H/2);ctx.lineTo(W/2+9,H/2);ctx.moveTo(W/2,H/2-9);ctx.lineTo(W/2,H/2+9);ctx.stroke();
}
function shoot(){if(!playing)return;let candidates=targets.filter(t=>t.alive).sort((a,b)=>Math.abs(project(a.x,a.y).x-W/2)-Math.abs(project(b.x,b.y).x-W/2));let hit=candidates.find(t=>Math.abs(project(t.x,t.y).x-W/2)<Math.max(24, W*.045));shots.push({x:W/2+(Math.random()-.5)*16,y:H*.52});setTimeout(()=>shots.shift(),90);if(hit){hit.alive=false;score++;scoreEl.textContent=score;setTimeout(()=>{hit.x=(Math.random()-.5)*900;hit.y=180+Math.random()*650;hit.alive=true;},1200);}else if(Math.random()<.12){health=Math.max(0,health-5);healthEl.textContent=health;if(health===0){playing=false;document.querySelector('#overlay h1').textContent='انتهت الجولة';document.querySelector('#overlay p').textContent='حققت '+score+' إصابة';document.getElementById('overlay').style.display='grid';}}}
function loop(ts){let dt=Math.min((ts-last)/16,2)||1;last=ts;if(playing){if(keys.w)player.y-=5*dt;if(keys.s)player.y+=5*dt;if(keys.a)player.x-=5*dt;if(keys.d)player.x+=5*dt;}render();requestAnimationFrame(loop);}
addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.code==='Space'){e.preventDefault();shoot();}});addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
canvas.addEventListener('mousemove',e=>{if(playing){player.angle=e.clientX/W;}});
document.querySelectorAll('[data-key]').forEach(b=>{let k=b.dataset.key;for(let ev of ['pointerdown','pointerup','pointerleave','pointercancel'])b.addEventListener(ev,e=>{e.preventDefault();keys[k]=ev==='pointerdown';});});
document.getElementById('fire').addEventListener('pointerdown',e=>{e.preventDefault();shoot();});
document.getElementById('start').onclick=()=>{playing=true;document.getElementById('overlay').style.display='none';canvas.requestPointerLock?.();};
resize();requestAnimationFrame(loop);
})();